<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>www.dream2jobs.info/pvt-job</title>
    <link rel="stylesheet" href="../allpages.css">
    <link rel="stylesheet" href="../../style.css">
    <link rel="stylesheet" href="../../res-all-pg.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jersey+25+Charted&display=swap" rel="stylesheet">
</head>

<body>

    

    <!-- header section  -->
    <header id="navbar">
        <div class="logo">
            <img src="../../lg.png" alt="">
        </div>
        <div class="menubar">
            <ul>
                <li><a href="../../index.php">Home</a></li>
                <li><a href="./pvt.php" id="private">Private Jobs</a></li>
                <li><a href="../Goverment jobs/gvr.php">Government Jobs</a></li>
                <li><a href="#fd-sec">Contact Us</a></li>
            </ul>
        </div>
    </header>
    <section class="landing-pg">
        <img src="./lp-svg.svg" alt="img">
        <div class="caption">
            <p>Search your Dream Private Job <br>
                Your dream job awaits. Apply now!
            </p>

            <a type="button" href="#fd-sec">Give Your Feedback</a>
        </div>

    </section>
    <!-- alert section  -->
    <div class="alert">
        <h2>Alert Link</h2>
        <marquee onMouseOver="this.stop()" onMouseOut="this.start()" behavior="alternate" scrollamount="3"><a
                href="#">JOIN OUR WHATSAPP GROUP</a> || <a href="#">FOLLOW ON
                INSTAGRAM</a> || <a href="#">FOLLOW ON TWITTER</a> || <a href="#">SUBSCRIBE ON YOUTUBE</a>
        </marquee>
        <marquee onMouseOver="this.stop()" onMouseOut="this.start()" onmousedown="this.stop()" onmouseup="this.start()"
            behavior="alternate" direction="right" scrollamount="3"><a href="#">RGPV RESULT OUT</a> || <a href="#">NTA
                CUET UG EXAM CITY AND DATE 2024</a> || <a href="#">CBSE CLASS 12TH RESULT</a></marquee>
        <marquee onMouseOver="this.stop()" onMouseOut="this.start()" behavior="alternate" direction="LEFT"
            scrollamount="3"><a href="#">AIR FORCE GROUP Y ONLINE FORM</a> ||
            <a href="#">NET ONLINE FORM 2024</a> || <a href="#">BIHAR STET ADMIT CARD 2024</a>
        </marquee>
        <marquee onMouseOver="this.stop()" onMouseOut="this.start()" behavior="alternate" direction="right"
            scrollamount="3"><a href="#">UP CPET ADMISSION ONLINE FORM
                2024</a> || <a href="#">UPSIFS ADMISSION ONLINE FORM 2024</a> || <a href="#">UGC NET JUNE 2024 FORM
                ONLINE</a></marquee>
    </div>
    <!-- private section  -->
    <section class="pvt">
        <div class="pvtjob">
            <h3>Private Jobs</h3>
            <ul>
                <li>
                    <a href="#" target="_blank">Area Sales Manager - Welgrow Technologies Private Limited</a>

                </li>
                <li>
                    <a href="#" target="_blank">Network Solutions Manager - Vegayan Systems</a>

                </li>
                <li>

                    <a href="#" target="_blank">Web Developer - Saviour Education Abroad</a>
                </li>
                <li>
                    <a href="#" target="_blank">Senior Systems Engineer - Amazon India Limited</a>

                </li>
                <li>
                    <a href="#" target="_blank">Accountant/ Accounts Executive - S J Healthcare Private Limited

                    </a>

                </li>
                <li>
                    <a href="#" target="_blank">Full-stack Developer - Web Crypt Technology </a>

                </li>
                <li>
                    <a href="#" target="_blank">Air Force Medical Assistant Group Y Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">Bihar BGSYS Lekhpal IT Assistant Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">NVS Non Teaching Various Post Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">India Post Payment Bank IT Executive Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">UPSSSC Junior Engineer JE Online Form 2024</a>

                </li>
                <li>

                    <a href="#" target="_blank">IIT Jodhpur Non Teaching Various Post Online Form 2024</a>
                </li>
                <li>
                    <a href="#" target="_blank">UPSIFS Lucknow Teaching / Non Teaching Various Post Online Form</a>
                </li>
                <li>
                    <a href="#" target="_blank">NTA CSIR UGC NET Online Form 2024</a>
                </li>
                <li>
                    <a href="#" target="_blank">UPSSSC Technical Assistant Group C Online Form 2024</a>
                </li>
            </ul>


        </div>
        <!-- <div class="pvtsyllabus">
            <h3>Online Free Courses</h3>
            <ul>
                <li>
                    <a href="#" target="_blank">NTA UGC NET June 2024 Online Form </a>

                </li>
                <li>
                    <a href="#" target="_blank">UPSC NDA II Online Form 2024</a>

                </li>
                <li>

                    <a href="#" target="_blank">Railway RPF Constable / Sub Inspector Correction / Edit Form 2024</a>
                </li>
                <li>
                    <a href="#" target="_blank">Army 10+2 TES 52 Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">Indian Navy Agniveer SSR / MR Online Form 02/2024 Batch</a>

                </li>
                <li>
                    <a href="#" target="_blank">SSC CHSL 10+2 Correction / Edit Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">Air Force Medical Assistant Group Y Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">Bihar BGSYS Lekhpal IT Assistant Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">NVS Non Teaching Various Post Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">India Post Payment Bank IT Executive Online Form 2024</a>

                </li>
                <li>
                    <a href="#" target="_blank">UPSSSC Junior Engineer JE Online Form 2024</a>

                </li>
                <li>

                    <a href="#" target="_blank">IIT Jodhpur Non Teaching Various Post Online Form 2024</a>
                </li>
                <li>
                    <a href="#" target="_blank">UPSIFS Lucknow Teaching / Non Teaching Various Post Online Form</a>
                </li>
                <li>
                    <a href="#" target="_blank">NTA CSIR UGC NET Online Form 2024</a>
                </li>
                <li>
                    <a href="#" target="_blank">UPSSSC Technical Assistant Group C Online Form 2024</a>
                </li>
            </ul>

        </div> -->
    </section>

    <!-- Form Section  -->

    <section class="fd-sec" id="fd-sec">
        <div class="container">
            <div class="contactInfo">
                <div>
                    <h2>Contact Info</h2>
                    <ul class="info">
                        <li>
                            <span><i class="bi bi-geo-alt"></i></span>
                            <span>UP , INDIA</span>
                            </span>
                        </li>
                        <li>
                            <span><i class="bi bi-envelope-at"></i></span>
                            <!-- <span>nassosanagn@gmail.com</span> -->
                            <span><a href="mailto: nassosanagn@gmail.com">mr.amankhann@gmail.com</a></span>
                        </li>
                        <li>
                            <span><i class="bi bi-telephone"></i></span>
                            <span>+91 9984473128</span>
                        </li>

                    </ul>
                </div>
                <ul class="sci">
                    <li><a href="#"><i class="bi bi-linkedin"></i></a></li>
                    <li><a href="#"><i class="bi bi-twitter"></i></a></li>
                    <li><a href="#"><i class="bi bi-instagram"></i></a></li>
                    <li><a href="#"><i class="bi bi-telegram"></i></a></li>

                </ul>
            </div>
            <div class="contactForm">
                <h2>Send a Message</h2>
                <div class="formBox">
                    <div class="inputBox w50">
                        <input type="text" name="" required>
                        <span>First Name</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="text" required>
                        <span>Last Name</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="email" required>
                        <span>Email Address</span>
                    </div>
                    <div class="inputBox w50">
                        <input type="text" required>
                        <span>Mobile Number</span>
                    </div>
                    <div class="inputBox w100">
                        <textarea required></textarea>
                        <span>Write your message here...</span>
                    </div>
                    <div class="inputBox w100">
                        <input type="submit" value="Send">
                    </div>
                </div>
            </div>



    </section>
    <!-- Footer section  -->

    <!-- Footer -->
    <footer class="text-center text-lg-start bg-body-tertiary text-muted ">
        <!-- Section: Social media -->
        <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
            <!-- Left -->
            <div class="me-5 d-none d-lg-block">
                <span>Get connected with us on social networks:</span>
            </div>
            <!-- Left -->

            <!-- Right -->
            <div>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-facebook"></i>
                </a>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-google"></i>
                </a>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-instagram"></i>
                </a>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-linkedin"></i>
                </a>
                <a href="" class="me-4 text-reset">
                    <i class="fab fa-github"></i>
                </a>
            </div>
            <!-- Right -->
        </section>
        <!-- Section: Social media -->

        <!-- Section: Links  -->
        <section class="bg-secondary text-white">
            <div class="container text-center text-md-start p-3">
                <!-- Grid row -->
                <div class="row mt-3">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                        <!-- Content -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            <i class="fas fa-gem me-3"></i>Dream2Jobs
                        </h6>
                        <p>“Unleash Your Potential: Find the Job That Fits Not Just Your Skills, But Your Passion.”
                            “Success is not the key to happiness. Happiness is the key to success. If you love what you
                            are doing, you will be successful.” 💪
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            Catagories
                        </h6>
                        <p>
                            <a href="#!" class="text-reset">Find Private Jobs</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Goverment Jobs</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Internship</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Feedback</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            Useful links
                        </h6>
                        <p>
                            <a href="#!" class="text-reset">Search</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Results</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Syllabus</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Help</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                        <p> <i class="fab fa-linkedin"></i> LinkedIn </p>
                        <p>
                            <i class="fas fa-envelope me-3"></i>
                            info@example.com
                        </p>
                        <p><i class="fas fa-phone me-3"></i> +91 9984473128</p>
                        <p><i class="fas fa-print me-3"></i> +91 9984473128</p>
                    </div>
                    <!-- Grid column -->
                </div>
                <!-- Grid row -->
            </div>
        </section>
        <!-- Section: Links  -->

        <!-- Copyright -->
        <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
            © 2021 Copyright:
            <a class="text-reset fw-bold" href="#">Created by MCA</a>
        </div>
        <!-- Copyright -->
    </footer>

    <!-- Footer -->
    <!-- fixed btn for pg-up  -->
    <button onclick="topFunction()" id="myFxdBtn" title="Go to top"><i class="bi bi-arrow-up-circle"></i></button>
    <script src="../../main.js"></script>
    <!-- php code for taking form data  -->

  <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mno = $_POST['mno'];
        $msg = $_POST['msg'];
        
      
      // Connecting to the Database
      $servername = "localhost";
      $username = "root";
      $password = "";
      $database = "fd-data";

      // Create a connection
      $conn = mysqli_connect($servername, $username, $password, $database);
      // Die if connection was not successful
      if (!$conn){
          die("Sorry we failed to connect: ". mysqli_connect_error());
      }
      else{ 
        // Submit these to a database
        // Sql query to be executed 
        $sql = "INSERT INTO `fd-data` (`fname`, `lname`, `mno`, `msg`) VALUES ('$fname', '$lname', '$mno', '$msg')";
        $result = mysqli_query($conn, $sql);
        if($result){
                $message = "Your Message Has Been Sent .";
                echo "<script type='text/javascript'>alert('$message');</script>";
        
          }
 
             }

    }

    
 ?> 
</body>

</html>